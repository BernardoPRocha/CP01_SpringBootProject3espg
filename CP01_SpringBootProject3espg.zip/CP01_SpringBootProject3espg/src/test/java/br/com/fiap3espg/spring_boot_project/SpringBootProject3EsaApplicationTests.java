package br.com.fiap3espg.spring_boot_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProject3EsaApplicationTests {

    @Test
    void contextLoads() {
    }

}
