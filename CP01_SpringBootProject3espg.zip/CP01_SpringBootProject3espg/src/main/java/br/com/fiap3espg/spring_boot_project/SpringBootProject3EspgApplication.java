package br.com.fiap3espg.spring_boot_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProject3EspgApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootProject3EspgApplication.class, args);
    }

}