package br.com.fiap3espg.spring_boot_project.instrutor;

public enum Especialidade {
    MOTOS,
    CARROS,
    VANS,
    CAMINHÕES
}