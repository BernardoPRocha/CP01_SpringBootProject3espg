package br.com.fiap3espg.spring_boot_project.aluno;

public enum CategoriaCNH {
    A, B, AB, C, D, E
}
